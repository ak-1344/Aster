# Non-Negotiable Rules

1. Never modify the project architecture unless explicitly instructed.

2. Never skip documentation updates.

3. Never preload future phases into To-Do.md.

4. Never edit previous entries in log.md.

5. Never leave the repository in a broken or non-runnable state.

6. Always treat To-Do.md as the single source of truth for the current implementation batch.

7. If architecture.md, plan.md, and To-Do.md conflict, follow architecture.md and report the conflict in log.md.

8. Never silently ignore implementation issues. Record them under "Known Issues" in To-Do.md with an appropriate severity.



# ASTER Development Rules

## Architecture

- Never redesign the architecture.
- Respect module boundaries.
- One module = one responsibility.
- Nodes never call other nodes directly.
- The Scheduler coordinates execution.
- The Planner decides execution strategy.

## Development

- Implement only the current To-Do phase.
- Never preload future phases.
- Finish the current phase before starting the next.
- Never leave partially implemented features.

## Documentation

- `To-Do.md` is the source of truth for the current work.
- `CurrentStatus.md` always reflects the latest repository state.
- `log.md` is append-only.
- Record all implementation issues in `To-Do.md` with a severity:
  - Critical
  - High
  - Medium
  - Low

## Code Quality

- Follow PEP-8.
- Use meaningful names.
- Keep modules loosely coupled.
- Prefer reusable components.
- Keep the project runnable after every batch.

## Priority

If documents conflict, follow:

architecture.md
→ plan.md
→ idea.md
→ To-Do.md