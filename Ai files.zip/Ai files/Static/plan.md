# PROJECT_PLAN.md

# ASTER - Development Guide

> Version: 1.0
>
> Status: Active Development
>
> This document serves as the master implementation guide for ASTER. It defines the project's vision, architecture philosophy, development roadmap, coding standards, technology stack, and engineering principles.

---

# 1. Project Vision

## Goal

ASTER is an intelligent, agentic analytics platform capable of transforming natural language business queries into executable analytical workflows.

Rather than forcing users to understand data science, SQL, or machine learning pipelines, ASTER understands the user's objective and determines the analytical process required to answer it.

The system focuses on three core principles:

- Understand
- Execute
- Explain

---

## Long-Term Vision

ASTER is designed as a modular analytical reasoning engine.

Although the initial implementation focuses on customer segmentation and personalization, the architecture is intentionally generic enough to support additional analytical domains in the future.

Potential future domains include:

- Fraud Detection
- Credit Risk Assessment
- Loan Recommendation
- Customer Churn Prediction
- Financial Forecasting
- Sales Analytics
- Healthcare Analytics

Customer Segmentation serves as the first proof-of-concept implementation.

---

# 2. Development Philosophy

The project follows several engineering principles.

## Principle 1

Build a working system before building a perfect system.

A simple working implementation is always preferred over an unfinished complex implementation.

---

## Principle 2

Every phase must leave the project in a runnable state.

No phase should break previous functionality.

---

## Principle 3

Never redesign the architecture unless absolutely necessary.

Implementation evolves.

Architecture remains stable.

---

## Principle 4

Every module should have one responsibility.

Avoid creating modules that perform multiple unrelated tasks.

---

## Principle 5

Business logic must remain independent from the API layer.

FastAPI should only expose endpoints.

It should never contain analytical logic.

---

## Principle 6

Optimization happens after correctness.

Do not introduce unnecessary complexity during the MVP.

---

# 3. Technology Stack

## Programming Language

Python 3.11+

Reason:

- Excellent ML ecosystem
- Mature data processing libraries
- Rapid development
- Large community

---

## Backend Framework

FastAPI

Responsibilities

- REST API
- File Upload
- Query Endpoints
- Response Delivery

Reason

- Lightweight
- Async support
- Automatic API documentation
- Excellent Python integration

---

## Data Processing

Pandas

Responsibilities

- Dataset loading
- Cleaning
- Aggregation
- Feature Engineering

---

NumPy

Responsibilities

- Numerical computation
- Mathematical operations
- Matrix manipulation

---

## Machine Learning

Scikit-Learn

Responsibilities

- Customer Segmentation
- Data Scaling
- Feature Transformation
- Model Evaluation

Initial Algorithms

- KMeans

Future

- DBSCAN
- HDBSCAN
- Gaussian Mixture Models

---

## Explainability

SHAP

Responsibilities

Explain model predictions.

---

LIME

Responsibilities

Local explanation generation.

---

## Visualization

Plotly

Responsibilities

Interactive charts

- Scatter Plot
- Pie Chart
- Cluster Visualization
- Heatmaps

Reason

Interactive visualizations suitable for dashboards.

---

## LLM

Gemini API

Responsibilities

Natural language understanding.

Used only for

- Intent Recognition
- Query Planning
- Explanation Generation

Not used for analytical computation.

---

## Database

SQLite

Initial Version

Reason

Simple
Portable
No configuration

Future

PostgreSQL

---

## Cache

Phase 1

Python Dictionary

Future

Redis

---

## Frontend

Next.js

Reason

- React ecosystem
- Server-side rendering
- Excellent UI flexibility

UI Library

Tailwind CSS

---

## Version Control

Git

Repository Structure

main

↓

feature branches

↓

merge after testing

---

# 4. Project Structure

The project follows a modular architecture.

Each module owns one responsibility.

No module should depend on internal implementation details of another module.

Communication should happen only through well-defined interfaces.

---

# 5. Development Roadmap

---

# Phase 0

Project Setup

Objectives

- Create repository
- Create folder structure
- Configure virtual environment
- Install dependencies
- Setup Git

Deliverables

- Clean project structure
- Requirements file
- Empty modules

Exit Criteria

Project compiles.

---

# Phase 1

Dataset Understanding

Objectives

Understand every column in the dataset.

Tasks

- Inspect dataset
- Missing value analysis
- Datatype analysis
- Statistical summary
- Identify customer identifier
- Identify transaction identifier

Deliverables

Dataset documentation.

Exit Criteria

Complete understanding of the dataset.

---

# Phase 2

Feature Engineering

Objectives

Convert transaction-level information into customer-level behaviour.

Possible Features

- Monthly Spend
- Average Spend
- Maximum Spend
- Transaction Frequency
- Merchant Diversity
- Weekend Ratio
- Night Transaction Ratio
- Dormancy Score
- Digital Usage Ratio
- Spending Trend
- Category Preferences

Deliverables

customer_features.csv

Exit Criteria

Every customer represented by behavioural features.

---

# Phase 3

Analytical Nodes

Develop each node independently.

Nodes

Analytics

Responsibilities

General statistics.

---

EDA

Responsibilities

Exploratory analysis.

---

Feature Engineering

Responsibilities

Generate behavioural features.

---

Segmentation

Responsibilities

Cluster customers.

---

Recommendation

Responsibilities

Recommend products.

Initially rule-based.

---

Evaluation

Responsibilities

Silhouette Score

Cluster quality

---

Visualization

Responsibilities

Generate charts.

Exit Criteria

Each node independently testable.

---

# Phase 4

Planner

Objectives

Interpret user intent.

Initially

Hardcoded planner.

Example

Query

"Segment customers"

↓

Planner

↓

Feature Node

↓

Segmentation Node

↓

Visualization

Exit Criteria

Planner generates execution workflow.

---

# Phase 5

Execution Engine

Objectives

Create execution graph.

Responsibilities

Scheduler executes nodes in order.

Future

Parallel execution.

---

# Phase 6

API Layer

Objectives

Expose REST endpoints.

Endpoints

/upload

/query

/status

Exit Criteria

Complete backend API.

---

# Phase 7

Frontend

Objectives

Interactive dashboard.

Features

- Chat Interface
- Dataset Upload
- Graphs
- Recommendations
- Tables

Exit Criteria

End-to-end working application.

---

# Phase 8

LLM Integration

Replace hardcoded planner.

Workflow

Query

↓

Gemini

↓

Intent JSON

↓

Planner

↓

Execution Graph

Exit Criteria

Natural language workflow generation.

---

# Phase 9

Explainability

Objectives

Explain analytical decisions.

Workflow

Model

↓

SHAP

↓

LIME

↓

LLM

↓

Human explanation

Exit Criteria

Every prediction explainable.

---

# Phase 10

Advanced Features

- Cache
- Model Registry
- Decision Memory
- Authentication
- Session Management
- Metrics Dashboard

These are enhancements.

Not MVP requirements.

---

# 6. Module Responsibilities

Planner

Responsible for

"What should be executed?"

Never performs computation.

---

Scheduler

Responsible for

"When should each node execute?"

Never makes analytical decisions.

---

Nodes

Responsible for

"How is the computation performed?"

Never invoke other nodes directly.

---

Explainability

Responsible for

Explaining outputs.

Never modifies predictions.

---

Frontend

Responsible only for presentation.

No business logic.

---

# 7. AI Usage

Traditional Programming

- Data Loading
- Cleaning
- Feature Engineering
- API
- Scheduler

Machine Learning

- Segmentation
- Evaluation

LLM

- Intent Recognition
- Query Planning
- Explanation Generation

The LLM never replaces analytical computation.

---

# 8. Coding Standards

Follow PEP8.

Use type hints.

Use docstrings.

Avoid global variables.

Prefer composition over inheritance.

Keep functions short.

One responsibility per function.

Meaningful variable names.

Write reusable code.

---

# 9. Git Rules

Commit frequently.

One feature per commit.

Never commit broken code.

Meaningful commit messages.

Example

feat: add segmentation node

fix: handle missing transaction values

docs: update planner workflow

---

# 10. Testing Strategy

Every node should be tested independently.

Before integration:

Analytics

↓

EDA

↓

Feature Engineering

↓

Segmentation

↓

Recommendation

↓

Visualization

Only after every node works independently should integration begin.

---

# 11. Future Improvements

- Parallel Execution
- Distributed Nodes
- Better Planner
- Automatic Model Selection
- Better Recommendations
- RAG Integration
- Streaming Responses
- Multi-user Support
- Container Deployment
- Cloud Deployment

---

# 12. Development Rules

Rule 1

Never redesign the architecture.

---

Rule 2

One module.

One responsibility.

---

Rule 3

Every phase ends with a runnable project.

---

Rule 4

Do not optimize prematurely.

---

Rule 5

Document every important decision.

---

Rule 6

Keep implementation modular.

---

Rule 7

Finish one phase before starting another.

---

Rule 8

A working feature is better than five unfinished features.

---

# Final Objective

Build a modular, explainable, and intelligent analytical system that can understand business questions, construct analytical workflows, execute them efficiently, and present trustworthy insights to users through natural language interaction.