# ASTER Architecture

Version: 1.1

Status: Architecture Finalized (v1.1 — Dataset Alignment Amendment)

Amendment note: v1.1 adds current-implementation notes to Sections 13, 16, and 17 to reflect the actual selected dataset (`CC GENERAL.csv`, pre-aggregated customer-level data). No architectural layers, modules, or responsibilities changed — this is a data-layer clarification only, per Development Rule 3 ("never redesign the architecture unless absolutely necessary").

---

# Table of Contents

1. Introduction
2. Architectural Philosophy
3. Design Principles
4. High-Level Project Architecture
5. Modular Architecture
6. System Architecture
7. Data Architecture
8. Query Execution Lifecycle
9. Module Specifications
10. Planner Design
11. Execution Graph
12. Scheduler
13. Explainability
14. Future Architecture
15. Design Decisions

---

# 1. Introduction

## Purpose

ASTER is an intelligent, agent-driven analytics platform designed to automate analytical reasoning over structured customer data.

Unlike traditional dashboards or machine learning pipelines that execute predefined analytical workflows, ASTER dynamically constructs an execution workflow based on the user's intent.

The objective is not to expose machine learning models directly to end users, but rather to provide an intelligent analytical assistant capable of deciding:

- what needs to be analysed,
- which analytical modules should execute,
- in what order they should execute,
- how the results should be presented,
- and how every important decision should be explained.

The system separates **reasoning**, **execution**, and **presentation** into independent architectural layers, allowing each responsibility to evolve independently.

---

# 2. Architectural Philosophy

ASTER follows an **Agent-Oriented Modular Architecture**.

Instead of treating analytics as a fixed sequence of operations, ASTER treats every user query as a planning problem.

Traditional analytical systems usually follow a pipeline similar to:

```

Load Dataset
↓

Clean Data
↓

Engineer Features
↓

Run Model
↓

Display Results

```

Regardless of the user's objective, every stage executes.

ASTER replaces this static pipeline with dynamic execution.

```

User Query
↓

Understand Intent
↓

Construct Execution Workflow
↓

Execute Required Modules
↓

Generate Insights
↓

Explain Decisions

```

This approach significantly improves flexibility while keeping the analytical components modular and reusable.

---

# 3. Core Design Principles

The architecture follows several software engineering principles.

## 3.1 Separation of Responsibilities

Each module performs exactly one responsibility.

Examples:

- Planner decides **what** should execute.
- Scheduler decides **when** modules execute.
- Nodes perform **how** computations are executed.
- Explainability describes **why** results were generated.

No component should perform responsibilities belonging to another layer.

---

## 3.2 Modular Design

ASTER is composed of multiple independent modules.

Each module communicates only through clearly defined interfaces.

Modules must remain loosely coupled.

Benefits include:

- easier maintenance
- independent testing
- easier debugging
- future scalability
- simple replacement of algorithms

---

## 3.3 Extensibility

Every analytical capability should exist as an independent module.

Future analytical nodes should be added without requiring changes to existing modules.

For example, introducing a Fraud Detection Node should not require modifications to the Segmentation Node.

The Planner should simply become capable of invoking the additional node whenever appropriate.

---

## 3.4 Explainability

The architecture assumes that analytical decisions must always be explainable.

The objective is not only to produce accurate outputs, but also to provide sufficient reasoning for business users to understand:

- why a customer belongs to a segment,
- which behavioural characteristics influenced that decision,
- what business actions are recommended,
- and how those recommendations were generated.

Explainability is therefore treated as a first-class architectural component rather than an optional feature.

---

## 3.5 Incremental Development

ASTER is intentionally designed to evolve.

The project begins with a minimal implementation and gradually introduces advanced architectural capabilities.

Initial versions prioritise correctness.

Future versions prioritise optimisation.

---

# 4. High-Level Project Architecture

ASTER can be viewed as four independent layers.

```

Presentation Layer

↓

Application Layer

↓

Analytical Layer

↓

Data Layer

```

Each layer has clearly defined responsibilities.

---

## Presentation Layer

Responsible for all user interaction.

Responsibilities include:

- Chat Interface
- Dataset Upload
- Interactive Charts
- Visualisations
- Tables
- Recommendation Display

This layer never performs business logic.

---

## Application Layer

Acts as the orchestration layer.

Responsible for:

- Request Management
- Query Processing
- Planning
- Workflow Generation
- Scheduling
- Response Composition

This layer coordinates execution but performs very little analytical computation.

---

## Analytical Layer

Responsible for domain-specific computation.

Modules include:

- Analytics
- EDA
- Feature Engineering
- Segmentation
- Recommendation
- Evaluation
- Visualisation

Every analytical node can operate independently.

---

## Data Layer

Responsible for data persistence.

Current responsibilities:

- Dataset Loading
- Processed Features
- Intermediate Results

Future responsibilities include:

- Cache
- Decision Memory
- Model Registry
- Persistent Storage

---

# 5. References

The following diagrams describe the architecture visually.

Overall System

`/home/ak/Desktop/Data/Coding/Projects/Aster---Distributed-Thinking/Diagrams/OverAllModel.png`

Detailed Architecture

`/home/ak/Desktop/Data/Coding/Projects/Aster---Distributed-Thinking/Diagrams/Detailed_Design.png`

Revised Architecture

`/home/ak/Desktop/Data/Coding/Projects/Aster---Distributed-Thinking/Diagrams/Detailed_Design_v1.png`

Explainability Architecture

`/home/ak/Desktop/Data/Coding/Projects/Aster---Distributed-Thinking/Diagrams/ExplainableArch.png`

Alternative Architecture Discussion

`/home/ak/Desktop/Data/Coding/Projects/Aster---Distributed-Thinking/Diagrams/Claude Suggestion.png`

---

# End of Shard 1

# 6. System Architecture

## Overview

ASTER follows a layered, modular architecture where every component performs a single responsibility.

The system does not execute a predefined pipeline. Instead, it constructs a workflow dynamically based on the user's request.

At a high level, every request follows the sequence below.

```

User
│
▼
Frontend
│
▼
API Layer
│
▼
Query Manager
│
▼
Context Builder
│
▼
Planner
│
▼
Execution Graph
│
▼
Task Scheduler
│
▼
Analytical Nodes
│
▼
Decision Engine
│
▼
Response Composer
│
▼
Frontend

```

Each component contributes one specific capability to the overall system.

---

# 7. Modular Architecture

ASTER is intentionally divided into independent modules.

Each module owns exactly one responsibility and communicates only through clearly defined inputs and outputs.

```

Presentation Layer

│

├── Frontend

│

Application Layer

│

├── API Gateway

├── Query Manager

├── Context Builder

├── Planner

├── Execution Graph

├── Task Scheduler

├── Response Composer

│

Analytical Layer

│

├── Analytics Node

├── EDA Node

├── Feature Engineering Node

├── Segmentation Node

├── Recommendation Node

├── Evaluation Node

├── Visualization Node

│

Decision Layer

│

├── Decision Engine

│

Data Layer

│

├── Dataset

├── Knowledge Layer

├── Cache (Future)

├── Model Registry (Future)

├── Decision Memory (Future)

```

This separation allows every component to evolve independently without affecting unrelated modules.

---

# 8. Component Specifications

## 8.1 Frontend

### Purpose

The Frontend serves as the interaction layer between users and ASTER.

Its responsibility is limited to collecting user input and presenting system responses.

### Responsibilities

- Chat interface
- Dataset upload
- Result tables
- Interactive visualisations
- Customer segment display
- Recommendation display

### What it should NOT do

The frontend should never perform:

- Feature Engineering
- Machine Learning
- Query Planning
- Business Logic

Those responsibilities belong exclusively to the backend.

---

## 8.2 API Layer

### Purpose

Acts as the entry point into the backend.

Every request from the frontend passes through the API layer before reaching the analytical engine.

### Responsibilities

- Receive HTTP requests
- Validate input
- Upload datasets
- Forward analytical queries
- Return responses

The API should remain intentionally lightweight.

It should never contain analytical logic.

---

## 8.3 Query Manager

### Purpose

The Query Manager acts as the controller for every user request.

Every analytical query passes through this module before planning begins.

### Responsibilities

- Receive user query
- Normalize input
- Forward request to Context Builder
- Coordinate execution lifecycle
- Handle execution status

The Query Manager never decides how the query should be solved.

Its responsibility is orchestration.

---

## 8.4 Context Builder

### Purpose

Transforms raw user input into structured analytical context.

This module prepares the information required by the Planner.

### Responsibilities

Extract:

- user intent
- entities
- requested output type
- customer filters
- execution constraints

Example

User:

```

Show premium customers from Chennai.

```

Context

```

Intent:
Customer Segmentation

Entity:
Premium

Filter:
City = Chennai

Output:
Table

```

The Context Builder performs interpretation but not planning.

---

## 8.5 Planner

### Purpose

The Planner is the intelligence behind ASTER.

Its job is to determine which analytical modules should execute.

It does **not** perform computation.

Instead, it creates an execution strategy.

Example

User Query

```

Find customers suitable for investment products.

```

Planner Output

```

Feature Engineering

↓

Segmentation

↓

Recommendation

↓

Visualization

```

The planner focuses only on deciding *what* should happen.

---

## 8.6 Execution Graph

### Purpose

Represents the analytical workflow generated by the Planner.

Instead of immediately executing modules, ASTER first builds a graph describing the required execution order.

Example

```

Feature Engineering

↓

Segmentation

↓

Evaluation

↓

Visualization

↓

Recommendation

```

The Execution Graph serves as the contract between planning and execution.

---

## 8.7 Task Scheduler

### Purpose

The Scheduler converts the Execution Graph into actual execution.

Responsibilities include

- executing nodes
- preserving execution order
- managing dependencies
- collecting outputs

The Scheduler never decides *which* nodes should execute.

That responsibility belongs exclusively to the Planner.

---

# 9. Request Lifecycle

Every request passes through the same lifecycle.

```

User Query

↓

API

↓

Query Manager

↓

Context Builder

↓

Planner

↓

Execution Graph

↓

Scheduler

↓

Nodes

↓

Decision Engine

↓

Response Composer

↓

Frontend

```

The analytical workflow itself changes depending on the query.

Only the lifecycle remains constant.

---

# 10. Dynamic Workflow Generation

One of ASTER's defining characteristics is that analytical workflows are generated dynamically.

Example 1

User asks

```

Show missing values.

```

Workflow

```

Analytics

↓

EDA

```

Example 2

User asks

```

Segment customers based on spending behaviour.

```

Workflow

```

Feature Engineering

↓

Segmentation

↓

Evaluation

↓

Visualization

```

Example 3

User asks

```

Recommend banking products for high-value customers.

```

Workflow

```

Feature Engineering

↓

Segmentation

↓

Recommendation

↓

Decision Engine

```

Every query produces its own execution graph.

No workflow is permanently hardcoded into the system.

---

# 11. Separation of Decision Making and Execution

ASTER intentionally separates reasoning from computation.

The Planner decides:

- What should execute?

The Scheduler decides:

- When should it execute?

The Nodes decide:

- How should the computation be performed?

The Decision Engine decides:

- How should the results be explained?

Keeping these responsibilities independent makes the architecture significantly easier to maintain and extend.

---

# End of Shard 2


# 12. Analytical Layer

## Overview

The Analytical Layer forms the computational core of ASTER.

While the Planner determines **what** should be executed and the Scheduler determines **when** execution should occur, the Analytical Layer determines **how** analytical computation is performed.

Each analytical capability is implemented as an independent node.

Nodes are intentionally designed to remain loosely coupled.

They never invoke one another directly.

Instead, every node receives structured input from the Scheduler and returns structured output to the execution pipeline.

```
                Analytical Layer

                Analytics
                     │
                     ▼
                   EDA
                     │
                     ▼
          Feature Engineering
                     │
                     ▼
              Segmentation
                     │
                     ▼
             Recommendation
                     │
                     ▼
               Evaluation
                     │
                     ▼
             Visualization
```

Each node may execute independently depending on the execution graph generated by the Planner.

---

# 13. Dataset Architecture

ASTER primarily operates on structured banking datasets.

Rather than viewing the dataset as a single CSV file, ASTER treats it as an operational banking database.

## Dataset Alignment Note (Current Implementation — v1.1)

The pipeline below describes the general, dataset-agnostic shape ASTER is designed to support.

The dataset selected for the current implementation is `CC GENERAL.csv` (Kaggle "Credit Card Dataset for Clustering"): 18 columns, **already aggregated to one row per customer** over a six-month window (`BALANCE`, `PURCHASES`, `ONEOFF_PURCHASES`, `INSTALLMENTS_PURCHASES`, `CASH_ADVANCE`, `CREDIT_LIMIT`, `PAYMENTS`, `MINIMUM_PAYMENTS`, `PRC_FULL_PAYMENT`, `TENURE`, and associated frequency/count columns).

This means, for the current implementation:

- Stages 1–2 below (raw transaction ingestion, cleaning) are **not applicable** — there is no transaction-level table to aggregate.
- Feature Engineering (Stage 3) operates on already-aggregated customer fields, producing **derived ratios**, not transaction-to-customer aggregation.
- No merchant, category, channel, income, or timestamp fields exist in this dataset. Any feature or cluster archetype referencing those (see Sections 16–17) is part of the generic/future design, not the current build.

The generic transaction-level pipeline is retained below as the target shape for future datasets (e.g. `bank_transactions.csv`, which is transaction-level with demographics but still lacks merchant/category fields).

```
Raw Dataset

↓

Cleaning

↓

Preprocessing

↓

Feature Engineering

↓

Customer Behaviour Dataset

↓

Segmentation

↓

Recommendation

↓

Business Insights
```

The objective is to transform raw transactional information into meaningful customer behavioural profiles.

---

## Data Processing Pipeline (Generic / Future Shape)

Stage 1

Raw Transaction Data

Contains:

- Customer ID
- Transaction Amount
- Timestamp
- Merchant
- Category
- Payment Method
- Location

↓

Stage 2

Cleaned Dataset

- Missing values removed
- Invalid records handled
- Data types corrected
- Duplicates removed

↓

Stage 3

Feature Engineering

Behavioural features generated.

↓

Stage 4

Customer Feature Table

One row represents one customer.

↓

Stage 5

Analytical Nodes

Customer-level analytics begin.

---

## Data Processing Pipeline (Current Implementation — CC GENERAL.csv)

Stage 1

Raw Customer-Level Dataset

Contains (already one row per customer):

- CUST_ID
- BALANCE, BALANCE_FREQUENCY
- PURCHASES, ONEOFF_PURCHASES, INSTALLMENTS_PURCHASES
- CASH_ADVANCE, CASH_ADVANCE_TRX, CASH_ADVANCE_FREQUENCY
- PURCHASES_FREQUENCY, ONEOFF_PURCHASES_FREQUENCY, PURCHASES_INSTALLMENTS_FREQUENCY, PURCHASES_TRX
- CREDIT_LIMIT, PAYMENTS, MINIMUM_PAYMENTS, PRC_FULL_PAYMENT, TENURE

↓

Stage 2

Cleaned Dataset

- Nulls in `MINIMUM_PAYMENTS` / `CREDIT_LIMIT` handled
- Data types corrected
- Duplicates removed (unlikely given `CUST_ID` uniqueness, verify)

↓

Stage 3

Feature Engineering

Derived ratios computed from existing columns (no aggregation needed — see Section 16 "Current Implementation Features").

↓

Stage 4

Customer Feature Table

Already one row per customer; Stage 4 output = Stage 1 input + derived ratio columns.

↓

Stage 5

Analytical Nodes

Customer-level analytics begin.

---

# 14. Analytics Node

## Purpose

The Analytics Node performs initial inspection of the dataset.

This node provides high-level information regarding the dataset before any analytical processing begins.

---

## Responsibilities

- Dataset dimensions
- Missing value analysis
- Column information
- Data types
- Numerical summaries
- Duplicate detection
- Cardinality analysis

---

## Input

```
DataFrame
```

---

## Output

```
Dataset Summary

Missing Values

Column Statistics

Basic Metrics
```

---

## Dependencies

None.

This node can execute independently.

---

# 15. Exploratory Data Analysis Node

## Purpose

Perform exploratory statistical analysis.

The objective is to understand relationships within the dataset before feature engineering begins.

---

## Responsibilities

- Distribution analysis
- Correlation analysis
- Category frequency
- Outlier detection
- Statistical summaries
- Initial visualisations

---

## Possible Outputs

- Correlation Matrix
- Histograms
- Box Plots
- Category Distribution
- Missing Value Heatmaps

---

# 16. Feature Engineering Node

## Purpose

The Feature Engineering Node transforms raw transactional information into behavioural customer characteristics.

This node is one of the most important components within ASTER.

Machine learning quality depends heavily on the quality of engineered features.

---

## Philosophy

Banks rarely cluster customers directly using raw transactions.

Instead, transactions are converted into behavioural indicators.

ASTER follows the same principle.

---

## Input

```
Transaction Dataset
```

---

## Output

```
Customer Behaviour Dataset
```

Each customer becomes a single behavioural profile.

---

## Current Implementation Features (CC GENERAL.csv)

These are the features actually computed by the Feature Engineering Node for the current build. All are derivable from existing columns — no external data required.

- `credit_utilization = BALANCE / CREDIT_LIMIT`
- `avg_purchase_size = PURCHASES / PURCHASES_TRX`
- `cash_advance_dependency = CASH_ADVANCE / (PURCHASES + CASH_ADVANCE)`
- `monthly_purchase_rate = PURCHASES / TENURE`
- `oneoff_vs_installment_ratio = ONEOFF_PURCHASES / (INSTALLMENTS_PURCHASES + 1)`
- `full_payment_ratio` — passthrough of `PRC_FULL_PAYMENT`

---

## Candidate Behavioural Features (Generic / Future Datasets)

The list below is retained as the target feature set for a richer, transaction-level dataset (e.g. one with merchant, category, channel, or income fields). None of these are implemented against the current dataset.

Financial Behaviour

- Monthly Spend
- Average Transaction Value
- Maximum Transaction
- Minimum Transaction
- Salary Credit Frequency
- Credit Utilization

Transaction Behaviour

- Transaction Frequency
- Spending Trend
- Weekend Spending Ratio
- Night Transaction Ratio
- Merchant Diversity
- Category Diversity

Customer Behaviour

- Dormancy Score
- Digital Usage Ratio
- Cash Withdrawal Ratio
- Online Transaction Ratio
- Regional Activity

Lifestyle Indicators

- Travel Spending
- Food Spending
- Entertainment Spending
- Shopping Behaviour
- Utility Payments

Risk Indicators

- Large Purchase Frequency
- Failed Transaction Ratio
- Irregular Spending Pattern

These engineered features become the foundation of customer segmentation once a richer dataset is adopted.

---

# 17. Segmentation Node

## Purpose

Group customers exhibiting similar behavioural characteristics.

Unlike demographic segmentation, ASTER focuses primarily on behavioural segmentation.

---

## Initial Algorithm

KMeans

Reason

- Stable
- Fast
- Easy to explain
- Suitable for MVP

---

## Future Algorithms

- DBSCAN
- HDBSCAN
- Gaussian Mixture Models

These algorithms can later be selected dynamically through the Model Registry.

---

## Input

Customer Behaviour Dataset

---

## Output

```
Customer ID

↓

Cluster ID

↓

Cluster Statistics
```

---

## Example Customer Groups (Current Implementation — CC GENERAL.csv)

Cluster A — Revolvers

High balance, high cash-advance dependency, low full-payment ratio

→ Retention / balance-transfer recommendation

---

Cluster B — Transactors

High purchases, high full-payment ratio, low cash advance

→ Premium rewards card upsell

---

Cluster C — Dormant

Low frequency across purchases, cash advance, and payments

→ Retention campaign

---

Cluster D — Premium One-Off Spenders

High one-off purchases, high credit limit

→ Investment / premium banking upsell

These names are generated after analysing cluster behaviour rather than predefined manually. Actual labels are assigned post-clustering based on the resulting centroid values, not hardcoded.

---

## Example Customer Groups (Generic / Future Datasets)

The groups below require fields not present in the current dataset (income, travel/merchant category, age, digital channel) and are retained as targets for a richer dataset:

Cluster — High Income, High Investment, Low Credit Usage

Cluster — Frequent Traveller, High Card Usage, Premium Spending

Cluster — Young Digital Customers, Frequent Small Transactions, High Digital Adoption

---

# 18. Recommendation Node

## Purpose

Generate actionable business recommendations based on analytical results.

Recommendations transform clusters into business value.

---

## Initial Implementation

Rule-Based

Example

```
Cluster

↓

Rule Engine

↓

Recommendation
```

Example

Premium Customers

↓

Premium Credit Card

---

Dormant Customers

↓

Retention Campaign

---

Young Professionals

↓

Savings Account Upgrade

---

## Future Improvements

Later versions may combine

- Rule Engine
- Business Policies
- LLM-generated recommendations

to improve recommendation quality.

---

# 19. Evaluation Node

## Purpose

Measure the quality of generated customer segments.

Segmentation should never be accepted without validation.

---

## Initial Metrics

- Silhouette Score
- Davies-Bouldin Index
- Calinski-Harabasz Score

These metrics provide objective measurements of clustering quality.

---

## Responsibilities

- Compare cluster quality
- Validate segmentation
- Assist future model selection

---

# 20. Visualization Node

## Purpose

Convert analytical outputs into business-friendly visualisations.

Visualisation makes analytical results understandable to non-technical users.

---

## Responsibilities

Generate

- Scatter Plots
- Pie Charts
- Cluster Distribution
- Heatmaps
- Spending Trends
- Customer Comparison Charts

Interactive visualisations improve exploration and decision making.

---

# 21. Node Independence

A fundamental architectural principle is that nodes remain independent.

Incorrect Design

```
Segmentation

↓

calls

↓

Recommendation
```

Correct Design

```
Scheduler

↓

Segmentation

↓

Scheduler

↓

Recommendation
```

The Scheduler is solely responsible for coordinating execution.

Nodes should never invoke one another directly.

This design significantly improves:

- modularity
- testing
- maintainability
- future scalability

---

# 22. Analytical Layer Summary

The Analytical Layer converts structured banking data into actionable business intelligence.

Its responsibilities include:

- understanding data,
- generating behavioural features,
- identifying customer groups,
- producing recommendations,
- validating analytical quality,
- and presenting insights visually.

The analytical nodes remain entirely independent of planning, scheduling, and presentation layers, ensuring that computational logic remains reusable across future analytical workflows.

---

# End of Shard 3


# 23. Planning & Orchestration Layer

## Overview

The Planning & Orchestration Layer is the intelligence of ASTER.

Unlike conventional analytical systems that execute a predefined pipeline, ASTER first reasons about the user's request before deciding how to solve it.

This layer is responsible for transforming natural language into an executable analytical workflow.

It does **not** perform analytics itself.

Instead, it decides:

- What should be executed?
- Which analytical modules are required?
- What dependencies exist?
- In what order should modules execute?
- Which outputs should be returned?

The Planning Layer is therefore completely independent from the Analytical Layer.

---

# 24. Planning Workflow

Every analytical request follows the same planning lifecycle.

```
Natural Language Query

        │
        ▼

 Query Manager

        │
        ▼

 Context Builder

        │
        ▼

     Planner

        │
        ▼

 Execution Graph

        │
        ▼

 Task Scheduler

        │
        ▼

 Analytical Nodes
```

Only after planning is complete does computation begin.

---

# 25. Query Manager

## Purpose

The Query Manager acts as the controller for every incoming request.

It is responsible for coordinating the planning process but never performs planning itself.

---

## Responsibilities

- Receive requests
- Validate requests
- Maintain execution context
- Forward requests to Context Builder
- Track execution state
- Handle execution failures
- Return responses

---

## Input

```
Natural Language Query
```

Example

```
Segment customers based on spending behaviour.
```

---

## Output

Structured execution request forwarded to the Context Builder.

---

## Design Principle

The Query Manager should remain intentionally lightweight.

Business reasoning belongs elsewhere.

---

# 26. Context Builder

## Purpose

The Context Builder converts an unstructured natural language query into structured metadata.

This metadata becomes the Planner's input.

---

## Responsibilities

Extract

- Intent
- Entities
- Filters
- Time constraints
- Requested output
- User preferences

---

## Example

Input

```
Show premium customers in Chennai.
```

Output

```json
{
    "intent": "customer_segmentation",
    "entity": "premium",
    "filter": {
        "city": "Chennai"
    },
    "output": "table"
}
```

---

## Why separate Context Builder?

Separating context extraction from planning allows:

- simpler Planner implementation
- reusable parsing logic
- future support for multiple LLMs
- easier testing

---

# 27. Planner

## Purpose

The Planner is responsible for analytical reasoning.

Given structured context, it determines the optimal execution workflow.

It does **not** perform analytics.

It produces a plan.

---

## Responsibilities

Determine

- required analytical nodes
- execution order
- dependencies
- optional steps
- output requirements

---

## Example

Input

```
Find customers suitable for investment products.
```

Planner Output

```
Feature Engineering

↓

Segmentation

↓

Recommendation

↓

Visualization
```

---

## Planner Philosophy

The Planner never asks

> Which algorithm should I run?

Instead it asks

> Which analytical capabilities are required?

Algorithms remain an implementation detail of each node.

---

## Future Improvements

Future versions may support

- cost-aware planning
- adaptive planning
- model selection
- planner feedback loops

without changing downstream modules.

---

# 28. Execution Graph

## Purpose

The Execution Graph is the Planner's final output.

Rather than directly invoking nodes, the Planner creates a graph representing dependencies between analytical tasks.

---

Example

```
Analytics

↓

EDA

↓

Feature Engineering

↓

Segmentation

↓

Recommendation

↓

Visualization
```

The Scheduler executes this graph.

---

## Why use a graph?

Graphs provide significant flexibility.

For example

```
Feature Engineering

        │

 ┌──────┴──────┐

 ▼             ▼

EDA     Segmentation

        │

        ▼

Recommendation
```

Multiple branches can execute independently.

Future versions may execute them in parallel.

---

## Future Implementation

The Execution Graph may be represented using

- NetworkX
- LangGraph
- Custom DAG implementation

depending on project evolution.

---

# 29. Task Scheduler

## Purpose

The Scheduler converts the Execution Graph into actual execution.

It is responsible for orchestration.

---

## Responsibilities

- Resolve dependencies
- Execute nodes
- Collect outputs
- Track execution status
- Handle failures
- Pass outputs between nodes

---

## Scheduler Rules

The Scheduler must

- respect graph dependencies
- never reorder dependent nodes
- never modify analytical outputs
- never make planning decisions

---

## Example

Execution Graph

```
Feature Engineering

↓

Segmentation

↓

Recommendation
```

Scheduler performs

```
Execute Feature Engineering

↓

Store Output

↓

Execute Segmentation

↓

Store Output

↓

Execute Recommendation
```

---

# 30. Communication Between Nodes

Nodes never communicate directly.

Incorrect

```
Segmentation

↓

Recommendation
```

Correct

```
Scheduler

↓

Segmentation

↓

Scheduler

↓

Recommendation
```

This maintains loose coupling.

---

# 31. Decision Engine

## Purpose

The Decision Engine transforms analytical outputs into business explanations.

Unlike the Planner, which reasons about execution, the Decision Engine reasons about results.

---

## Responsibilities

- Explain clusters
- Explain recommendations
- Describe important features
- Generate business insights
- Translate technical outputs into business language

---

## Example

Model Output

```
Cluster = 2
```

Decision Engine

```
This customer belongs to Cluster 2 because of

- high monthly spending
- frequent travel
- premium card usage

Recommended products:

- Premium Credit Card
- Travel Insurance
- Investment Portfolio
```

---

## Explainability Pipeline

```
Model Output

        │

        ▼

SHAP / LIME

        │

Feature Contributions

        │

        ▼

LLM

        │

        ▼

Business Explanation
```

The LLM never explains without supporting analytical evidence.

---

# 32. Response Composer

## Purpose

The Response Composer assembles outputs from multiple analytical modules into a unified response.

---

## Responsibilities

Combine

- Tables
- Charts
- Recommendations
- Explanations
- Statistics
- Metadata

into one response object.

---

Example Response

```
Summary

↓

Cluster Statistics

↓

Charts

↓

Recommendations

↓

Explanation
```

The frontend receives only this final structured response.

---

# 33. AI Integration Strategy

ASTER intentionally limits where Large Language Models are used.

LLMs are responsible only for tasks requiring natural language reasoning.

Current usage:

| Component | LLM Required |
|-----------|--------------|
| Context Builder | Yes |
| Planner | Yes |
| Decision Engine | Optional (for explanation generation) |
| Recommendation Enhancement | Future |

Everything else uses deterministic programming or machine learning.

---

# 34. Why Separate Reasoning from Computation?

This is the defining architectural decision of ASTER.

Reasoning is inherently flexible.

Computation should remain deterministic.

If these responsibilities are mixed, the system becomes difficult to debug, maintain, and extend.

By separating them:

- analytical nodes remain reusable,
- planners become replaceable,
- multiple LLMs can be evaluated,
- workflows become dynamic,
- execution remains predictable.

This separation is what transforms ASTER from a traditional machine learning pipeline into an intelligent analytical system.

---

# End of Shard 4

# 35. Data Layer

## Overview

The Data Layer provides persistence and shared resources for the entire system.

Unlike the Analytical Layer, which performs computation, the Data Layer stores information that enables those computations.

The MVP implementation intentionally keeps this layer lightweight. As ASTER evolves, this layer can grow independently without affecting higher architectural layers.

```
                    Data Layer

           ┌──────────────────────┐
           │      Raw Dataset      │
           └──────────────────────┘
                     │
           ┌──────────────────────┐
           │  Processed Features   │
           └──────────────────────┘
                     │
        ┌────────────┼────────────┐
        ▼            ▼            ▼
 Knowledge      Decision      Model
   Layer         Memory       Registry

                     │
               Future Cache
```

---

# 36. Raw Dataset

The raw dataset is the source of truth.

It should never be modified directly.

Responsibilities:

- Transaction storage
- Customer information
- Historical records

All preprocessing and feature engineering should operate on copies of the dataset rather than mutating the original.

---

# 37. Processed Features

Feature Engineering produces a customer-level feature table.

This table becomes the primary input for downstream analytical nodes.

Example

```
Customer ID

↓

Monthly Spend

↓

Average Spend

↓

Dormancy Score

↓

Merchant Diversity

↓

Digital Usage Ratio

↓

Cluster Assignment
```

Keeping engineered features separate allows them to be reused by multiple analytical workflows.

---

# 38. Knowledge Layer

## Purpose

The Knowledge Layer stores business knowledge that is not learned from data.

Examples include:

- Banking product catalogue
- Product eligibility rules
- Business policies
- Segment definitions
- Recommendation templates

The Recommendation Node consults this layer when generating business actions.

Future versions may implement this as a Retrieval-Augmented Generation (RAG) component to provide richer contextual recommendations.

---

# 39. Decision Memory (Future)

## Purpose

Decision Memory stores historical execution information.

Rather than remembering conversations, it records analytical decisions.

Possible information includes:

- Execution graphs
- Planner outputs
- Cluster statistics
- Recommendation history
- Model versions
- Execution timestamps

This enables reproducibility and auditing of analytical workflows.

---

# 40. Model Registry (Future)

The Model Registry maintains metadata about analytical models available to ASTER.

Example

```
Segmentation

↓

KMeans

DBSCAN

HDBSCAN

Gaussian Mixture
```

Responsibilities

- Model discovery
- Version tracking
- Default model selection
- Evaluation history

The Planner does not directly interact with algorithms. It only specifies analytical capabilities. The Model Registry allows those capabilities to evolve independently.

---

# 41. Cache (Future)

Repeated analytical requests may generate identical intermediate results.

A cache layer can reduce execution time by storing:

- Processed datasets
- Engineered features
- Planner outputs
- Visualisations
- Intermediate node results

Future implementations may use Redis for distributed caching.

---

# 42. System Interfaces

Every module communicates through well-defined interfaces.

```
Frontend

↓

REST API

↓

Query Manager

↓

Planner

↓

Execution Graph

↓

Scheduler

↓

Analytical Nodes

↓

Response Composer

↓

Frontend
```

No module should access another module's internal implementation directly.

Communication occurs only through explicit inputs and outputs.

---

# 43. API Architecture

The API layer provides a stable interface between the frontend and the analytical engine.

### Core Endpoints

```
POST /upload
```

Upload customer datasets.

---

```
POST /query
```

Submit a natural language analytical request.

---

```
GET /status
```

Retrieve system health and execution status.

---

Future endpoints may include:

```
GET /history
GET /models
POST /explain
POST /segment
```

The API should remain thin, delegating all business logic to backend modules.

---

# 44. Security Considerations

Although the MVP targets local execution, the architecture is designed with future production deployment in mind.

Key considerations include:

- Authentication and authorisation
- Secure file uploads
- Input validation
- Rate limiting
- Audit logging
- Encryption of sensitive customer data
- Principle of least privilege

Security should be implemented as cross-cutting infrastructure rather than embedded within analytical modules.

---

# 45. Scalability Strategy

The modular design enables ASTER to scale horizontally.

Future enhancements may include:

- Distributed task execution
- Parallel node execution
- Microservice decomposition
- Cloud-native deployment
- Multiple planner backends
- GPU-accelerated analytical nodes

Because modules communicate through explicit interfaces, individual components can be replaced or scaled without redesigning the entire system.

---

# 46. Design Decisions

Several architectural decisions define ASTER.

## Why a Planner?

Without a Planner, every query would execute the same analytical pipeline regardless of intent.

Planning enables adaptive workflows.

---

## Why Independent Nodes?

Independent nodes improve:

- Testability
- Reusability
- Maintainability
- Extensibility

New capabilities can be introduced without modifying existing nodes.

---

## Why an Execution Graph?

Execution graphs make dependencies explicit.

They also enable future optimisations such as:

- Parallel execution
- Conditional execution
- Failure recovery
- Workflow visualisation

---

## Why Separate the Scheduler?

Scheduling and planning solve different problems.

The Planner reasons about *what* should happen.

The Scheduler ensures *how and when* those actions occur.

This separation simplifies both components.

---

## Why Use LLMs Selectively?

LLMs excel at natural language reasoning but should not replace deterministic analytical computation.

ASTER therefore limits LLM usage to:

- Intent understanding
- Workflow planning
- Natural language explanation

All numerical computation remains deterministic and reproducible.

---

# 47. End-to-End Execution Example

The following example illustrates the complete lifecycle of a request.

### User Query

```
Recommend suitable banking products for high-value customers.
```

---

### Step 1

Frontend submits the query to the API.

---

### Step 2

The Query Manager receives the request and forwards it to the Context Builder.

---

### Step 3

The Context Builder extracts structured information.

```
Intent:
Recommendation

Target:
High-value customers

Output:
Recommendations + Visualisations
```

---

### Step 4

The Planner determines the required analytical workflow.

```
Feature Engineering

↓

Segmentation

↓

Recommendation

↓

Visualization

↓

Decision Engine
```

---

### Step 5

The Execution Graph is generated.

---

### Step 6

The Scheduler executes each node in dependency order.

```
Feature Engineering

↓

Segmentation

↓

Recommendation

↓

Visualization

↓

Decision Engine
```

---

### Step 7

The Response Composer aggregates outputs.

```
Summary

Cluster Information

Recommended Products

Charts

Business Explanation
```

---

### Step 8

The frontend renders the response to the user.

The analytical workflow is complete.

---

# 48. Future Architecture

The current implementation represents the Minimum Viable Product (MVP).

The architecture has been designed to accommodate future capabilities without requiring major redesign.

Potential enhancements include:

- Multi-agent planning
- Distributed execution
- Real-time streaming analytics
- Automatic model selection
- Reinforcement learning for planning
- Knowledge graph integration
- Retrieval-Augmented Generation (RAG)
- Multi-domain analytical workflows
- Enterprise authentication
- Cloud deployment
- Workflow persistence
- Human-in-the-loop approvals

These enhancements extend the system while preserving its modular foundations.

---

# 49. Architecture Summary

ASTER is designed as an intelligent analytical platform rather than a traditional machine learning pipeline.

The architecture is intentionally layered:

- **Presentation Layer** handles user interaction.
- **Application Layer** manages orchestration and planning.
- **Analytical Layer** performs deterministic computation.
- **Decision Layer** generates explainable business insights.
- **Data Layer** provides persistence and shared knowledge.

By separating reasoning, execution, and computation, ASTER achieves:

- Modularity
- Explainability
- Extensibility
- Maintainability
- Scalability

This architecture allows new analytical capabilities to be introduced with minimal impact on existing components, making ASTER suitable not only for customer segmentation but also as a foundation for future intelligent analytical systems across multiple business domains.

---

# Appendix A – Architecture Diagram References

The following diagrams provide visual representations of the architecture described in this document.

Overall Architecture

`/home/ak/Desktop/Data/Coding/Projects/Aster---Distributed-Thinking/Diagrams/OverAllModel.png`

Detailed System Design

`/home/ak/Desktop/Data/Coding/Projects/Aster---Distributed-Thinking/Diagrams/Detailed_Design.png`

Revised Detailed Design

`/home/ak/Desktop/Data/Coding/Projects/Aster---Distributed-Thinking/Diagrams/Detailed_Design_v1.png`

Explainability Architecture

`/home/ak/Desktop/Data/Coding/Projects/Aster---Distributed-Thinking/Diagrams/ExplainableArch.png`

Alternative Architecture Exploration

`/home/ak/Desktop/Data/Coding/Projects/Aster---Distributed-Thinking/Diagrams/Claude Suggestion.png`

---

# End of Architecture.md