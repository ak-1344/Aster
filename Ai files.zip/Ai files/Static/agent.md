# ASTER Development Agent

You are responsible for implementing ASTER incrementally.

**All referenced documents are located in `Ai_files/` or `Ai_files/Static/`.**

## Instructions

1. **Strictly follow `Static/rules.md` throughout development.**
2. Read `To-Do.md` and implement **only** the current phase and its tasks.
3. Use `architecture_short.md` and `Architecture.yaml` as the primary architectural references. Refer to `architecture.md` only when additional detail is required.
4. Follow the implementation strategy defined in `plan.md` and the project objectives in `idea.md`.
5. After every completed batch:
   - Rewrite `CurrentStatus.md` to reflect the latest project state.
   - Log any bug, blocker, or design question encountered in `Issues.md`. Do **not** log routine completed tasks here — only genuine issues, risks, or open questions.
   - Append an entry to `CHANGELOG.md`. Never rewrite or delete a previously released version section.
   - Also Append the implementation details to `CHANGELOG.md` (raw chronological batch log; never modify previous entries).
6. If the current phase is complete:
   - Determine the next phase using `plan.md`, `architecture_short.md`, and `idea.md`.
   - Generate a new `To-Do.md` — **technical implementation tasks only**. No reference lists, no narrative context, no "why" explanations. See formatting standard below.
   - **Never load more than one active phase into `To-Do.md`.**
   - Move the just-finished phase's checklist into `To-Do.md`'s completed-milestone section (checked), rather than deleting it.

## Execution Order

```text
To-Do.md
    ↓
architecture_short.md
Architecture.yaml
    ↓
plan.md
idea.md
    ↓
Implementation
    ↓
CurrentStatus.md
Issues.md
CHANGELOG.md
log.md
    ↓
To-Do.md (only if the current phase is complete)
```

---

## Documentation Formatting Standards

These formats are fixed. Do not deviate, add narrative sections, or invent new headers.

### `To-Do.md` — technical tasks only

- Header: `# 📋 ASTER — ToDo`, then `> Maintained by agent. Updated after every task.` and `> Pull phase details from plan.md.`
- Exactly one active section: `## 🟡 Current Phase: Phase N — <name> (Blocking)`, a flat `- [ ]` checkbox list of concrete technical actions (commands, files, folders). No explanations, no rationale, no "reference documents" section.
- Optional `### Exit Criteria` sub-list under the current phase, also checkboxes, mechanically verifiable (a command that passes/fails), not descriptive.
- One `## Backlog — Phase N+1 onward` section: one unchecked line per remaining phase, name only, no sub-tasks yet.
- On phase completion, move it to `## ✅ Completed Milestone: Phase N — <name>` with every box checked. Never delete a completed section — this file accumulates like the ToDo.md example.

### `CurrentStatus.md`

- Header: `# 📍 ASTER — Current Status`, then `> Overwrite this every session. This is the single source of truth for where the project is.`
- Fields in order: `Active Milestone`, `Last Worked On`, `Overall Progress` (rough %).
- `## What's Working` — bullet list, bold the feature/module name, one-line description each.
- `## What's Not Yet Built` — flat bullet list of remaining phases/features.
- `## Blockers` — flat list, or state "None" if empty.
- `## ▶️ Next Action (Start Here Next Session)` — numbered list of concrete next steps.

### `Issues.md`

- Header: `# 🐛 ASTER — Issues`, then `> Log every bug, blocker, and design question here.` and `> Format: [ISSUE-XXX] with status tracking.`
- `## 🔴 Open Issues` — each as `### [ISSUE-XXX] — <title>` with fields: **Type**, **Found** (which phase), **Details**, **Status**, **Impact**, **Workaround** (if any), **Proposed Fix** (if known).
- `## 📌 Known Risks (Pre-emptive)` — each as `### [RISK-XXX] <title>` with **Details**, **Mitigation**, **Status**.
- `## ✅ Resolved Issues` — same fields as Open Issues, plus **Resolution**.
- Only genuine bugs, blockers, design questions, or pre-emptive risks belong here — never routine task completion (that's `CHANGELOG.md`'s job).

### `CHANGELOG.md`

- Follows [Keep a Changelog](https://keepachangelog.com/en/1.0.0/) and [Semantic Versioning](https://semver.org/spec/v2.0.0.html) — keep the standard header block.
- All new work lands under `## [Unreleased]`, grouped by `### Added` / `### Changed` / `### Fixed` / `### Removed` / `### Security` as applicable — omit empty groups.
- Cut a dated version section (`## [x.y.z] - YYYY-MM-DD`) only at a genuine milestone boundary (a completed Phase), not after every commit.
- Never edit or delete a previously released version section.

---

Always maintain architectural consistency, documentation synchronisation, and a runnable repository.
