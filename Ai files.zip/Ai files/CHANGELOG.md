# Changelog

All notable changes to ASTER will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- Phase 2 feature engineering deliverable with customer-level engineered features written to backend/data/processed/customer_features.csv.
- Feature engineering documentation in Docs/Feature_Engineering.md.

### Changed
- Activated Phase 3 analytical nodes as the current implementation milestone in the task tracker.

## [0.2.0] - 2026-07-25

### Added
- Reusable feature engineering utility at backend/utils/feature_engineering.py.
- Feature engineering node wrapper at backend/app/nodes/feature_engineering_node.py.
- Generated processed dataset artifact backend/data/processed/customer_features.csv.

### Changed
- Promoted Phase 2 to a completed milestone in the task tracker.
- Updated project status and next actions to target Phase 3 analytical nodes.

## [0.1.0] - 2026-07-25

### Added
- Phase 0 backend/app scaffold, dependency manifest, environment example, and frontend placeholder.
- Dataset-understanding utility and EDA node wrapper for the selected customer-level dataset.
- Dataset-understanding documentation covering schema, identifiers, missing values, and datatypes.

### Changed
- Promoted Phase 0 and Phase 1 checklists to completed milestones in the task tracker.
- Synchronized the project status documentation with the current repository state.
