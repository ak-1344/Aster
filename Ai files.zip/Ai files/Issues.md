# 🐛 ASTER — Issues
> Log every bug, blocker, and design question here.
> Format: [ISSUE-XXX] with status tracking.

## 🔴 Open Issues

## 📌 Known Risks (Pre-emptive)

### [RISK-002] Limited support for time-derived behaviour features
**Details**: The selected CC GENERAL dataset is customer-level and does not expose transaction timestamps, day-of-week, or merchant category timelines required for weekend ratio, night ratio, and spend trend features listed in the long-form plan.
**Mitigation**: Use available aggregate behavioural columns for Phase 2 and defer time-derived features unless a transaction-level dataset becomes the active source.
**Status**: Open

## ✅ Resolved Issues

### [ISSUE-001] Backend layout mismatch
**Type**: Design question / blocker
**Found**: Phase 0
**Details**: The repository currently has backend modules under backend/planner, backend/nodes, backend/scheduler, and related packages, while the Phase 0 checklist expects a newer backend/app layout with API, query manager, context builder, planner, execution graph, scheduler, response composer, nodes, and decision engine under that namespace.
**Status**: Resolved
**Impact**: Low
**Workaround**: Treat the current package tree as the active scaffold until the target layout is confirmed.
**Proposed Fix**: None required for Phase 0; revisit during Phase 6 if the older package tree needs consolidation.
**Resolution**: The Phase 0 app scaffold was added under backend/app, and the repository can import app.api.main from the backend directory without errors.

### [RISK-001] Environment bootstrap remains unverified
**Type**: Pre-emptive risk
**Found**: Phase 0
**Details**: Phase 0 initially required git initialization, virtual environment creation, dependency installation, and import validation.
**Status**: Resolved
**Impact**: Low
**Workaround**: None required after verification.
**Proposed Fix**: None.
**Resolution**: The repository already had git history, the project virtual environment was created, backend dependencies installed successfully, and the Phase 0 import check passed.
